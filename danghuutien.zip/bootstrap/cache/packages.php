<?php return array (
  'benjaminhirsch/nova-slug-field' => 
  array (
    'providers' => 
    array (
      0 => 'Benjaminhirsch\\NovaSlugField\\FieldServiceProvider',
    ),
  ),
  'digital-creative/collapsible-resource-manager' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\CollapsibleResourceManager\\CollapsibleResourceManagerServiceProvider',
    ),
  ),
  'digital-creative/nova-filepond' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\Filepond\\FilepondServiceProvider',
    ),
  ),
  'emilianotisato/nova-tinymce' => 
  array (
    'providers' => 
    array (
      0 => 'Emilianotisato\\NovaTinyMCE\\FieldServiceProvider',
    ),
  ),
  'ericlagarda/nova-gallery' => 
  array (
    'providers' => 
    array (
      0 => 'EricLagarda\\NovaGallery\\ToolServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'kaibatech/nova-actions-left' => 
  array (
    'providers' => 
    array (
      0 => 'Flagstudio\\NovaActionsLeft\\NovaActionsLeftServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'mayviet/fileupload' => 
  array (
    'providers' => 
    array (
      0 => 'Mayviet\\Fileupload\\FieldServiceProvider',
    ),
  ),
  'mayvietjsc/mvcms' => 
  array (
    'providers' => 
    array (
      0 => 'Mayvietjsc\\Mvcms\\ThemeServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'optimistdigital/nova-menu-builder' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\MenuBuilder\\MenuBuilderServiceProvider',
    ),
  ),
  'optimistdigital/nova-multiselect-field' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\MultiselectField\\FieldServiceProvider',
    ),
  ),
  'optimistdigital/nova-tailwind' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\Tailwind\\TailwindServiceProvider',
    ),
  ),
  'optimistdigital/nova-translations-loader' => 
  array (
    'providers' => 
    array (
    ),
    'aliases' => 
    array (
    ),
  ),
  'silvanite/brandenburg' => 
  array (
    'providers' => 
    array (
      0 => 'Silvanite\\Brandenburg\\Providers\\BrandenburgServiceProvider',
    ),
    'aliases' => 
    array (
      'BrandenburgPolicy' => 'Silvanite\\Brandenburg\\Facades\\PolicyFacade',
    ),
  ),
  'silvanite/novafieldcheckboxes' => 
  array (
    'providers' => 
    array (
      0 => 'Silvanite\\NovaFieldCheckboxes\\FieldServiceProvider',
    ),
  ),
  'silvanite/novatoolpermissions' => 
  array (
    'providers' => 
    array (
      0 => 'Silvanite\\NovaToolPermissions\\Providers\\AuthServiceProvider',
      1 => 'Silvanite\\NovaToolPermissions\\Providers\\PackageServiceProvider',
    ),
  ),
  'unisharp/laravel-filemanager' => 
  array (
    'providers' => 
    array (
      0 => 'UniSharp\\LaravelFilemanager\\LaravelFilemanagerServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'whitecube/nova-flexible-content' => 
  array (
    'providers' => 
    array (
      0 => 'Whitecube\\NovaFlexibleContent\\FieldServiceProvider',
    ),
  ),
);