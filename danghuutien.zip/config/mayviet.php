<?php

return [

    'tinh' =>  env('APP_TINH', 'NGHE AN'),

];
