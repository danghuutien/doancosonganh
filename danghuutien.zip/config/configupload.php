<?php

return [
 "doc" ,
 "docm" ,
 "docx" ,
 "xlsm" ,
 "xls" ,
 "xlsx" ,
 "pdf" ,
 "PDF" ,
 "jpg" ,
 "png" ,
 "mp4" ,

 "pptx" ,
 "ppt" ,
 "pps" ,
 "rar" ,
 "zip" ,
 
];
