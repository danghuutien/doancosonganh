<?php

namespace Database\Factories;

use App\Models\Sanpham;
use Illuminate\Database\Eloquent\Factories\Factory;

class SanphamFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Sanpham::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
