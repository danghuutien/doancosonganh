<?php

namespace Laravel\Nova\Exceptions;

use LogicException;

class LensCountException extends LogicException
{
    //
}
