<?php

namespace Laravel\Nova\Fields;

class MorphOne extends HasOne
{
    //
}
